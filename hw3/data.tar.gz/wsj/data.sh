cnt = 1
for i in `ls 00`;
do
    echo $i
    $cnt = $cnt + 1
done    
